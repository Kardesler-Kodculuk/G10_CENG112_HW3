/**
 * Contains the classes related to internal simulation.
 */
package simulation;